let body=document.querySelector('body').style.backgroundColor="ghostwhite";
let main=document.querySelector("main")
let squares=document.querySelector(".squares")
//code
bg()=>{
		body.style.backgroundColor="orange";
	squares.style.backgroundColor="black"
}
